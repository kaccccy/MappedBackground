
public class MappedBackgroundMain {
	
	public static void main(String[] args)
	{
		MappedBackgroundAnimation animation = new MappedBackgroundAnimation();
		AnimationFrame frame = new AnimationFrame((Animation)animation);
		frame.start();
	}

}
